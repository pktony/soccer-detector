# football-players-detection > 2025-05-16 5:21pm
https://universe.roboflow.com/soccer-detector/football-players-detection-3zvbc-7rn35

Provided by a Roboflow user
License: CC BY 4.0

